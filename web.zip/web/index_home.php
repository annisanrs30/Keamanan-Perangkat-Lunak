<?php
ob_start();
session_start();

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Home NIBAL</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="shortcut icon" href="img/lg.png">
  <style>
    body {
      font-family: "Times New Roman", Times, serif;
      background-color: #FFF8F3;
    }

    .navbar nav {
      margin: auto;
      text-align: center;
      width: 100%;
    }

    .navbar nav ul ul {
      display: none;
    }

    .navbar nav ul li:hover>ul {
      display: block;
      width: 150px;
    }

    .navbar nav ul {
      background: #FFF8F3;
      padding: 0 20px;
      list-style: none;
      position: relative;
      display: inline-table;
      width: 100%;
    }

    .navbar nav ul:after {
      content: "";
      clear: both;
      display: block;
    }

    .navbar nav ul li {
      float: right;
    }

    .navbar nav ul li:hover {
      background: #A8A8A8;
    }

    .navbar nav ul:hover a {
      color: #000;
    }

    .navbar nav ul li a {
      display: block;
      padding: 25px;
      color: #000;
      text-decoration: none;
      font-family: "Times New Roman", Times, serif;
      font-size: 25px;
    }

    .navbar nav ul ul {
      background: #A8A8A8;
      border-radius: 0px;
      padding: 0;
      position: absolute;
      top: 100%;
    }

    .navbar nav ul ul ul {
      position: absolute;
      right: 90%;
      top: 0;
    }

a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}

a:hover {
  background-color: #A8A8A8;
  color: black;
}

#card {
    background: #fbfbfb;
    border-radius: 8px;
    box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
    height: 515px;
    margin: 6rem auto 8.1rem auto;
    width: 427px;
    margin-top: 30px;
    margin-bottom: 30px;
}

#card-content {
    padding: 12px 44px;
}
#card-title {
    font-family: "Times New Roman", Times, serif;
    letter-spacing: 4px;
    padding-bottom: 23px;
    padding-top: 3px;
    text-align: center;
    margin-top: 30px;
}
.underline-title {
    background: -webkit-linear-gradient(right, #1d7dff,  #000);
    height: 2px;
    margin: 0.1rem auto 0 auto;
    width: 245px;
}
a {
    text-decoration: none;
}
label {
    font-family: "Times New Roman", Times, serif;
    font-size: 15pt;
}
.form {
    align-items: left;
    display: flex;
    flex-direction: column;
}
.form-border {
    background: -webkit-linear-gradient(right, #1d7dff,  #000);
    height: 2px;
    width: 100%;
}
.form-content {
    background: #fbfbfb;
    border: none;
    outline: none;
    padding-top: 14px;
}
#signup {
    color: #A8A8A8;
    font-family: "Times New Roman", Times, serif;
    font-size: 20pt;
    margin-top: 16px;
    text-align: center;
}
#submit {
    background: #A8A8A8;
    border: none;
    border-radius: 21px;
    box-shadow: 0px 1px 8px #888b8a;
    cursor: pointer;
    color: white;
    font-family: "Times New Roman", Times, serif;
    height: 42.3px;
    margin: 0 auto;
    margin-top: 30px;
    margin-bottom: 10px;
    transition: 0.25s;
    width: 153px;
    outline: none;
}
#submit:hover {
    box-shadow: 0px 1px 18px#858887;
}

    .footer {
      padding: 50px 0;
      color: #000;
      background-color: #FFF8F3;
      margin-top: 5px;
    }

    .footer .copyright {
      text-align: center;
      padding-top: 5px;
      opacity: 0.3;
      font-size: 13px;
      margin-bottom: 0;
    }
  </style>
</head>

<body>
  <div class="navbar">
    <nav>
      <ul>
        <li style="margin-top: 30px;"><a href="index_balok.php">Balok</a></li>
        <li style="margin-top: 30px;"><a href="index_nilai.php">Nilai</a></li>
        <li style="margin-top: 30px;"><a href="index_home.php">Home</a></li>

        <li style="margin-top: -110px; margin-right: 992px;">
          <a href="index_home.php">
            <img src="img/lg.png" style="height: 85px; width: 85px;"> Nilai & Balok</a>
        </li>
      </ul>
    </nav>
  </div>

<div class="container-fluid" id="codelatte">
<div class="row justify-content-center text-center" style="margin-top: 3%; margin-bottom: 2%; ">
  <div class="card float-left col-md-3 mr-3" style="width: 20%; border-radius: 5px; box-shadow: 1px 2px 4px #bdbcbc;">
    <div class="card-body">
      <h2 class="card-title" style="margin-bottom: 30px; margin-top: 30px;">NILAI</h2>
	    <img class="img-fluid mb-3" src="img/knv.png" alt="Card image cap" style="height: 150px; width: 150px;">
	    <p class="card-text" style="margin-top: 30px;"> Konversikan Nilai Disini ! </p>
	    <a href="index_nilai.php" class="btn btn-primary" style="background-color: #A8A8A8; border-color: #A8A8A8; margin-bottom: 30px;">
		  <i class="fa fa-sign-in"></i> Kunjungi Halaman</a>
    </div>
  </div>
  <div class="card float-left col-md-3 mr-3" style="width: 20%; border-radius: 5px; box-shadow: 1px 2px 4px #bdbcbc;">
    <div class="card-body">
      <h2 class="card-title" style="margin-bottom: 30px; margin-top: 30px;">BALOK</h2>
	    <img class="img-fluid mb-3" src="img/balok.png" alt="Card image cap" style="height: 150px; width: 150px;">
	    <p class="card-text" style="margin-top: 30px;"> Hitung Luas & Volume Balok Disini ! </p>
	    <a href="index_balok.php" class="btn btn-primary" style="background-color: #A8A8A8; border-color: #A8A8A8; margin-bottom: 30px;">
		  <i class="fa fa-sign-in"></i> Kunjungi Halaman</a>
    </div>
  </div>
</div>
</div>

  <div class="footer">
    <footer>
        <div class="container">
          <p class="copyright">Copyright © 2021 Annisa Rusydina Sabila. All Rights Reserved </p>
        </div>
    </footer>
  </div>
  </div>
</body>
</html>
