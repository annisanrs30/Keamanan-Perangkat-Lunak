<?php
    // cek apakah tombol submit dengan nama = "konversi" sudah ditekan atau belum
    if (isset($_POST['konversi'])) {
        $nama = $_POST["nama"];
        $nim = $_POST["nim"];
        $matkul = $_POST["matkul"];
        $absensi = (double)$_POST["absensi"];
        $tugas = (double)$_POST["tugas"];
        $uts = (double)$_POST["uts"];
        $uas = (double)$_POST["uas"];

        // Check apakah sudah memenuhi syarat atau belum
        if ( ($absensi < 0) || ($absensi > 100) || ($tugas < 0) || ($tugas > 100) || ($uts < 0) || ($uts > 100) || ($uas < 0) || ($uas > 100) ) {
            echo "<script>
                alert( 'Value range : 0.00 - 100' );
                documetugas$tugas.location.href = 'index_nilai.php';
            </script>";
        } else {
            // Penilaian :
            $absensi = $absensi*0.2;
            $absensi = number_format($absensi, 2, '.', ' ');
            $tugas = $tugas*0.3;
            $tugas = number_format($tugas, 2, '.', ' ');
            $uts = $uts*0.2;
            $uts = number_format($uts, 2, '.', ' ');
            $uas = $uas*0.3;
            $uas = number_format($uas, 2, '.', ' ');

            // jumlah Penilaian
            $jumlah = $absensi + $tugas + $uts + $uas;
            $jumlah = number_format($jumlah, 2, '.', ' ');

            // Nilai dan Indeks :
            if     ($jumlah < 40 )   { $angka = 0    ; $huruf = "E";  } 
            elseif ($jumlah < 55 )   { $angka = 1    ; $huruf = "D";  }
            elseif ($jumlah < 60 )   { $angka = 2    ; $huruf = "C";  }
            elseif ($jumlah < 65 )   { $angka = 2.5  ; $huruf = "C+"; }
            elseif ($jumlah < 70 )   { $angka = 2.75 ; $huruf = "B-"; }
            elseif ($jumlah < 75 )   { $angka = 3    ; $huruf = "B";  }
            elseif ($jumlah < 80 )   { $angka = 3.5  ; $huruf = "B+"; }
            elseif ($jumlah < 85 )   { $angka = 3.75 ; $huruf = "A-"; }
            elseif ($jumlah <= 100 ) { $angka = 4    ; $huruf = "A";  }
        }
    }
?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Nilai</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="shortcut icon" href="img/logonb.png">
  <style>
    body {
      font-family: "Times New Roman", Times, serif;
      background-color: #FFF8F3;
    }

    .navbar nav {
      margin: auto;
      text-align: center;
      width: 100%;
    }

    .navbar nav ul ul {
      display: none;
    }

    .navbar nav ul li:hover>ul {
      display: block;
      width: 150px;
    }

    .navbar nav ul {
      background: #FFF8F3;
      padding: 0 20px;
      list-style: none;
      position: relative;
      display: inline-table;
      width: 100%;
    }

    .navbar nav ul:after {
      content: "";
      clear: both;
      display: block;
    }

    .navbar nav ul li {
      float: right;
    }

    .navbar nav ul li:hover {
      background: #004aad;
    }

    .navbar nav ul:hover a {
      color: #000;
    }

    .navbar nav ul li a {
      display: block;
      padding: 25px;
      color: #000;
      text-decoration: none;
      font-family: "Times New Roman", Times, serif;
      font-size: 25px;
    }

    .navbar nav ul ul {
      background: #004aad;
      border-radius: 0px;
      padding: 0;
      position: absolute;
      top: 100%;
    }

    .navbar nav ul ul ul {
      position: absolute;
      right: 90%;
      top: 0;
    }

    .mySlides {
      display: none
    }

    .w3-left,
    .w3-right,
    .w3-badge {
      cursor: pointer
    }

    .w3-badge {
      height: 13px;
      width: 13px;
      padding: 0
    }

a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}

a:hover {
  background-color: #A8A8A8;
  color: black;
}

#card {
    background: #fbfbfb;
    border-radius: 8px;
    box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
    height: 760px;
    margin: 6rem auto 8.1rem auto;
    width: 427px;
    margin-top: 30px;
    margin-bottom: 30px;
}

#card-content {
    padding: 12px 44px;
}
#card-title {
    font-family: "Times New Roman", Times, serif;
    letter-spacing: 4px;
    padding-bottom: 23px;
    padding-top: 3px;
    text-align: center;
    margin-top: 30px;
}
.underline-title {
    background: -webkit-linear-gradient(right, #865439,  #C68B59);
    height: 2px;
    margin: 0.1rem auto 0 auto;
    width:280px;
}
a {
    text-decoration: none;
}
label {
    font-family: "Times New Roman", Times, serif;
    font-size: 15pt;
}
.form {
    align-items: left;
    display: flex;
    flex-direction: column;
}
.form-border {
    background: -webkit-linear-gradient(right, #865439,  #C68B59);
    height: 2px;
    width: 100%;
}
.form-content {
    background: #fbfbfb;
    border: none;
    outline: none;
    padding-top: 14px;
}

#submit {
    background: #004aad;
    border: none;
    border-radius: 21px;
    box-shadow: 0px 1px 8px #888b8a;
    cursor: pointer;
    color: white;
    font-family: "Times New Roman", Times, serif;
    height: 42.3px;
    margin: 0 auto;
    margin-top: 30px;
    margin-bottom: 10px;
    transition: 0.25s;
    width: 153px;
    outline: none;
}
#submit:hover {
    box-shadow: 0px 1px 18px#858887;
}

    .footer {
      padding: 50px 0;
      color: #000;
      background-color: #FFF8F3;
      margin-top: 5px;
    }

    .footer .copyright {
      text-align: center;
      padding-top: 5px;
      opacity: 0.3;
      font-size: 13px;
      margin-bottom: 0;
    }
  </style>
</head>

<body>
  <div class="navbar">
    <nav>
      <ul>
        <li style="margin-top: 30px;"><a href="index_balok.php">Balok</a></li>
        <li style="margin-top: 30px;"><a href="index_nilai.php">Nilai</a></li>
        <li style="margin-top: 30px;"><a href="index_home.php">Home</a></li>

        <li style="margin-top: -110px; margin-right: 992px;">
          <a href="index_home.php">
            <img src="img/lg.png" style="height: 85px; width: 85px;"> Nilai & Balok</a>
        </li>
      </ul>
    </nav>
  </div>

  <div class="container-fluid" id="codelatte">
    <div class="row justify-content-flex-end text-left" style="margin-top: 2%; margin-bottom: 3px; margin-left: 170px; ">
        <div class="card float-center col-md-5 mr-3" style="width: 20%; background: #fbfbfb; border-radius: 8px; box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.65);">
            <div class="card-body" style="width:">

                <div id="card-title">
                    <h2 style="font-size: 30px;">Isi Data Disini !</h2>
                    <div class="underline-title"></div>
                </div>

                <form action="" method="post" class="form">
                    <label for="nama_mahasiswa" style="padding-top:13px;">Nama Mahasiswa : </label>
                    <input class="form-content" type="text" name="nama" id="nama_mahasiswa" minlength="1" maxlength="100"
                        onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || (event.charCode==32)"
                        title="must be 1-100 character and contain only letters" placeholder="Nama Mahasiswa" required />
                    <div class="form-border"></div>

                    <label for="nim" style="padding-top:13px">NIM : </label>
                    <input class="form-content" type="text" name="nim" id="nim" min="0" minlength="11" maxlength="11"
                        pattern="[0-9]{11}" title="must be 11 characters in length and contain only numbers" placeholder="NIM" required />
                    <div class="form-border"></div>
                    
                    <label for="mata_kuliah" style="padding-top:13px">Mata Kuliah : </label>
                    <input class="form-content" type="text" name="matkul" id="mata_kuliah" minlength="1" maxlength="100"
                        onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || (event.charCode==32)"
                        title="must be 1-100 character and contain only letters" placeholder="Mata Kuliah" required />
                    <div class="form-border"></div>

                    <label for="absensi" style="padding-top:13px">Absensi (20%) : </label>
                    <input class="form-content" type="text" name="absensi" id="absensi" min="0" max="100" step="0.01"
                    minlength="1" maxlength="5" pattern="([0-9])+(\.[0-9][0-9]?)?"
                    title="only be filled with a value range of 0-100 with max 2 decimal (.00)"
                    placeholder="Value range : 0.00 - 100" required /> 
                    <?php if( isset($error) ) : ?>
                        <div class="invalid-feedback">
                            Value range : 0.00 - 100
                        </div>
                    <?php endif; ?>
                    <div class="form-border"></div>

                    <label for="tugas" style="padding-top:13px">Nilai Tugas (30%) : </label>
                    <input class="form-content" type="text" name="tugas" id="tugas" min="0" max="100" step="0.01"
                    minlength="1" maxlength="5" pattern="([0-9]{1,2})+(\.[0-9][0-9]?)?"
                    title="only be filled with a value range of 0-100 with max 2 decimal (.00)"
                    placeholder="Value range : 0.00 - 100" required />
                    <?php if( isset($error) ) : ?>
                        <div class="invalid-feedback">
                            Value range : 0.00 - 100
                        </div>
                    <?php endif; ?>
                    <div class="form-border"></div>
                    
                    <label for="uts" style="padding-top:13px">Nilai UTS (20%) : </label>
                    <input class="form-content" type="text" name="uts" id="uts" min="0" max="100" step="0.01"
                    minlength="1" maxlength="5" pattern="([0-9]{1,2})+(\.[0-9][0-9]?)?"
                    title="only be filled with a value range of 0-100 with max 2 decimal (.00)"
                    placeholder="Value range : 0.00 - 100" required />
                    <?php if( isset($error) ) : ?>
                        <div class="invalid-feedback">
                            Value range : 0.00 - 100
                        </div>
                    <?php endif; ?>
                    <div class="form-border"></div>

                    <label for="uas" style="padding-top:13px">Nilai UAS (30%) : </label>
                    <input class="form-content" type="text" name="uas" id="uas" min="0" max="100" step="0.01"
                    minlength="1" maxlength="5" pattern="([0-9]{1,2})+(\.[0-9][0-9]?)?"
                    title="only be filled with a value range of 0-100 with max 2 decimal (.00)"
                    placeholder="Value range : 0.00 - 100" required />
                    <?php if( isset($error) ) : ?>
                        <div class="invalid-feedback">
                            Value range : 0.00 - 100
                        </div>
                    <?php endif; ?>
                    <div class="form-border"></div>

                    <button type="submit" name="konversi" class="btn btn-primary btn-sm" style="background: #004aad;
                    border: none; border-radius: 21px; box-shadow: 0px 1px 8px #888b8a; cursor: pointer;
                    color: white; font-family: Arial, Helvetica, sans-serif; font-size: 15px; height: 42.3px; margin: 0 auto;
                    margin-top: 30px; margin-bottom: 10px; transition: 0.25s; width: 153px; outline: none;">Konversi</button>
                </form>
            </div>
        </div>
        
        <div class="card float-center col-md-5 mr-3" style="width: 20%; background: #fbfbfb; border-radius: 8px; box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.65);">
            <div class="card-body">
                <div id="card-title">
                    <h2 style="font-size: 30px;">Hasil Konversi</h2>
                    <div class="underline-title"></div>
                </div>

                <form action="" method="post" class="form">
                    <label for="nama_mahasiswa" style="padding-top:13px;">Nama Mahasiswa : </label>
                    <td><?php if ( isset($nama)) : ?>
                            <td style="width: 300px"><?= $nama ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>

                    <label for="nim" style="padding-top:13px">NIM : </label>
                    <td><?php if ( isset($nim)) : ?>
                            <td style="width: 300px"><?= $nim ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>

                    <label for="mata_kuliah" style="padding-top:13px">Mata Kuliah : </label>
                    <td><?php if ( isset($matkul)) : ?>
                            <td style="width: 300px"><?= $matkul ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>

                    <label for="absensi" style="padding-top:13px">Absensi (20%) : </label>
                    <td><?php if ( isset($absensi)) : ?>
                            <td style="width: 300px"><?= $absensi ?></td>
                        <?php endif; ?></td> 
                    <div class="form-border"></div>

                    <label for="tugas" style="padding-top:13px">Nilai Tugas (30%) : </label>
                    <td><?php if ( isset($tugas)) : ?>
                            <td style="width: 300px"><?= $tugas ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>
                    
                    <label for="uts" style="padding-top:13px">Nilai UTS (20%) : </label>
                    <td><?php if ( isset($uts)) : ?>
                            <td style="width: 300px"><?= $uts ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>

                    <label for="uas" style="padding-top:13px">Nilai UAS (30%) : </label>
                    <td><?php if ( isset($uas)) : ?>
                            <td style="width: 300px"><?= $uas ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>

                    <label for="jumlah" style="padding-top:13px">Nilai Akhir : </label>
                    <td><?php if ( isset($jumlah)) : ?>
                            <td style="width: 300px"><?= $jumlah ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>

                    <label for="angka" style="padding-top:13px">Indeks Angka : </label>
                    <td><?php if ( isset($angka)) : ?>
                            <td style="width: 300px"><?= $angka ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>

                    <label for="huruf" style="padding-top:13px">Indeks Huruf : </label>
                    <td><?php if ( isset($huruf)) : ?>
                            <td style="width: 300px"><?= $huruf ?></td>
                        <?php endif; ?></td>
                    <div class="form-border"></div>
                    <br><br>
                </form>
            </div>
        </div>
    </div>
</div>


      <center>
      </div>
    </div>
  </div>

  <div class="footer">
    <footer>
        <div class="container">
            <p class="copyright">Copyright © 2021 Annisa Rusydina Sabila. All Rights Reserved </p>
        </div>
    </footer>
  </div>
  </div>
</body>
</html>